package com.example.linkedmein;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedmeinApplicationTests {

	@Test
	void contextLoads() {
	}

} 


// cd C:\Dev\linkedmein
// mvn surefire-report:report
